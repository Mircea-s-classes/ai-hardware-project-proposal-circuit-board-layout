import sensor, time, ml, uos, gc

# Camera initialization
sensor.reset()                         # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)    # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)      # Set frame size to QVGA (320x240)
sensor.set_windowing((240, 240))       # Set 240x240 window.
sensor.skip_frames(time=2000)          # Let the camera adjust.

# Load model and labels
net = None
labels = None

try:
    net = ml.Model("trained.tflite",
                   load_to_fb=uos.stat('trained.tflite')[6] >
                   (gc.mem_free() - (64 * 1024)))
except Exception as e:
    print(e)
    raise Exception('Failed to load "trained.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

try:
    labels = [line.rstrip('\n') for line in open("labels.txt")]
except Exception as e:
    raise Exception('Failed to load "labels.txt", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

print("Model and labels loaded.")
print("Labels:", labels)

# Majority vote buffers
VOTE_WINDOW = 15
vote_labels = []
vote_scores = []

clock = time.clock()

while True:
    clock.tick()
    img = sensor.snapshot()

    # Inference and per-class probabilities
    scores = net.predict([img])[0].flatten().tolist()
    predictions_list = list(zip(labels, scores))

    print("---- New frame ----")
    for i in range(len(predictions_list)):
        print("%s = %f" % (predictions_list[i][0], predictions_list[i][1]))
    print(clock.fps(), "fps")

    # Best label for this frame
    best_idx = scores.index(max(scores))
    best_label = labels[best_idx]
    best_score = scores[best_idx]

    # Update sliding vote window
    vote_labels.append(best_label)
    vote_scores.append(best_score)
    if len(vote_labels) > VOTE_WINDOW:
        vote_labels.pop(0)
        vote_scores.pop(0)

    # Majority vote label and its average score
    majority_label = None
    majority_count = 0
    if vote_labels:
        for lab in set(vote_labels):
            c = vote_labels.count(lab)
            if c > majority_count:
                majority_count = c
                majority_label = lab

    majority_score = 0.0
    if majority_label is not None:
        s_sum = 0.0
        s_cnt = 0
        for lab, sc in zip(vote_labels, vote_scores):
            if lab == majority_label:
                s_sum += sc
                s_cnt += 1
        if s_cnt > 0:
            majority_score = s_sum / s_cnt

    # Overlay final label on the image and print to console
    if majority_label is not None:
        txt = "%s %.2f" % (majority_label, majority_score)
        img.draw_string(5, 5, txt, color=(255, 0, 0), scale=2)

    print("VOTE ->", majority_label, "avg_score =", majority_score)
